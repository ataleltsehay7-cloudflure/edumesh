package et.edumesh.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import org.json.JSONObject

/** የትምህርት ቤት ወርሃዊ ሪፖርት (ስሪት 1) */
data class EducationReport(
    val schoolName: String,
    val kebele: String,
    val period: String,          // ለምሳሌ "2019-03"
    val enrolledBoys: Int,
    val enrolledGirls: Int,
    val presentBoys: Int,
    val presentGirls: Int,
    val teachersTotal: Int,
    val teachersPresent: Int,
    val textbookShortage: Boolean,
    val waterSanitationIssue: Boolean,
    val urgent: Boolean,
    val note: String
) {
    fun toJson(): String = JSONObject().apply {
        put("schoolName", schoolName); put("kebele", kebele); put("period", period)
        put("enrolledBoys", enrolledBoys); put("enrolledGirls", enrolledGirls)
        put("presentBoys", presentBoys); put("presentGirls", presentGirls)
        put("teachersTotal", teachersTotal); put("teachersPresent", teachersPresent)
        put("textbookShortage", textbookShortage)
        put("waterSanitationIssue", waterSanitationIssue)
        put("urgent", urgent); put("note", note)
    }.toString()

    companion object {
        fun fromJson(s: String): EducationReport {
            val o = JSONObject(s)
            return EducationReport(
                o.getString("schoolName"), o.getString("kebele"), o.getString("period"),
                o.getInt("enrolledBoys"), o.getInt("enrolledGirls"),
                o.getInt("presentBoys"), o.getInt("presentGirls"),
                o.getInt("teachersTotal"), o.getInt("teachersPresent"),
                o.getBoolean("textbookShortage"), o.getBoolean("waterSanitationIssue"),
                o.getBoolean("urgent"), o.optString("note", "")
            )
        }
    }
}

object Kind { const val REPORT = "REPORT"; const val ACK = "ACK" }
object Status { const val DRAFT = "DRAFT"; const val IN_TRANSIT = "IN_TRANSIT"; const val DELIVERED = "DELIVERED" }

/**
 * በሜሽ ውስጥ የሚዘዋወር አንድ "ጥቅል" (bundle).
 * REPORT: blob = በወረዳ public key የተመሰጠረ ሪፖርት፣ dest = "WOREDA"
 * ACK:    blob = የሪፖርቱ id (ግልጽ ጽሁፍ)፣ dest = የላኪው nodeId
 */
@Entity(tableName = "bundles")
data class BundleEntity(
    @PrimaryKey val id: String,
    val kind: String,
    val dest: String,
    val origin: String,
    val blob: String,
    val createdAt: Long,
    val expiresAt: Long,
    val mine: Boolean,       // በዚህ ስልክ የተፈጠረ ነው?
    val consumed: Boolean,   // በዚህ ስልክ ተቀብሎ ተጠናቋል? (ከዚህ በኋላ አይተላለፍም)
    val title: String,       // ለላኪው ብቻ የሚታይ ርዕስ
    val urgent: Boolean,
    val status: String
)

@Entity(tableName = "received")
data class ReceivedEntity(
    @PrimaryKey val id: String,
    val json: String,
    val receivedAt: Long
)

@Dao
interface BundleDao {
    @Query("SELECT id FROM bundles")
    suspend fun allIds(): List<String>

    @Query("SELECT * FROM bundles WHERE id = :id")
    suspend fun get(id: String): BundleEntity?

    @Query("SELECT * FROM bundles WHERE consumed = 0 AND expiresAt > :now")
    suspend fun carryable(now: Long): List<BundleEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(b: BundleEntity)

    @Query("UPDATE bundles SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("UPDATE bundles SET consumed = 1 WHERE id = :id")
    suspend fun markConsumed(id: String)

    @Query("DELETE FROM bundles WHERE id = :id AND mine = 0")
    suspend fun deleteCarried(id: String)

    @Query("DELETE FROM bundles WHERE expiresAt < :now AND mine = 0")
    suspend fun purgeExpired(now: Long)

    @Query("SELECT * FROM bundles WHERE mine = 1 AND kind = 'REPORT' ORDER BY createdAt DESC")
    fun observeMine(): Flow<List<BundleEntity>>

    @Query("SELECT COUNT(*) FROM bundles WHERE mine = 0 AND consumed = 0")
    fun observeCarriedCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertReceived(r: ReceivedEntity)

    @Query("SELECT * FROM received ORDER BY receivedAt DESC")
    fun observeReceived(): Flow<List<ReceivedEntity>>
}

@Database(entities = [BundleEntity::class, ReceivedEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): BundleDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "edumesh.db")
                .build().also { inst = it }
        }
    }
}
