package et.edumesh.mesh

import android.content.Context
import et.edumesh.crypto.Crypto
import et.edumesh.data.*
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * ስልክ-ለስልክ ልውውጥ (Epidemic routing / store-and-forward).
 *
 * ሁለት ስልኮች ሲገናኙ፦
 *  1. እያንዳንዳቸው "የያዝኩት ጥቅል id ዝርዝር" (summary vector) ይልካሉ።
 *  2. እያንዳንዳቸው ሌላኛው የሌለውን ጥቅል ብቻ ይልካሉ።
 *  3. REPORT ወደ ወረዳ ስልክ ሲደርስ ይፈታል፣ ACK ይፈጠራል፣ በተመሳሳይ መንገድ ወደ ላኪው ይመለሳል።
 *
 * ማሳሰቢያ: Nearby BYTES payload ከ ~32KB መብለጥ የለበትም (ሪፖርቱ በጣም ያነሰ ነው)።
 */
class MeshManager(
    ctx: Context,
    private val db: AppDb,
    private val nodeId: String,
    private val isWoreda: () -> Boolean,
    private val woredaPrivateKey: () -> String?
) {
    private val client = Nearby.getConnectionsClient(ctx.applicationContext)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val dao = db.dao()
    private val connected = ConcurrentHashMap.newKeySet<String>()

    companion object {
        const val SERVICE_ID = "et.edumesh.v1"
        const val TTL_MS = 14L * 24 * 3600 * 1000   // 14 ቀን
    }

    fun start() {
        val strategy = Strategy.P2P_CLUSTER
        client.startAdvertising(
            nodeId, SERVICE_ID, lifecycle,
            AdvertisingOptions.Builder().setStrategy(strategy).build()
        )
        client.startDiscovery(
            SERVICE_ID, discovery,
            DiscoveryOptions.Builder().setStrategy(strategy).build()
        )
        scope.launch { dao.purgeExpired(System.currentTimeMillis()) }
    }

    fun stop() {
        client.stopAdvertising()
        client.stopDiscovery()
        client.stopAllEndpoints()
        connected.clear()
    }

    // ---------- ግኝትና ግንኙነት ----------

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            // ሁለቱም ወገን በአንድ ጊዜ እንዳይጠይቁ፦ ትንሹ id ብቻ ይጠይቃል
            if (nodeId < info.endpointName && !connected.contains(endpointId)) {
                client.requestConnection(nodeId, endpointId, lifecycle)
            }
        }
        override fun onEndpointLost(endpointId: String) {}
    }

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            client.acceptConnection(endpointId, payloads)
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                connected.add(endpointId)
                scope.launch { sendSummary(endpointId) }
            }
        }

        override fun onDisconnected(endpointId: String) {
            connected.remove(endpointId)
        }
    }

    // ---------- መልዕክት መላክ/መቀበል ----------

    private suspend fun sendSummary(endpointId: String) {
        val ids = JSONArray(dao.allIds())
        val msg = JSONObject().put("t", "SV").put("ids", ids)
        client.sendPayload(endpointId, Payload.fromBytes(msg.toString().toByteArray()))
    }

    private val payloads = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            val bytes = payload.asBytes() ?: return
            scope.launch {
                try {
                    val o = JSONObject(String(bytes))
                    when (o.getString("t")) {
                        "SV" -> onSummary(endpointId, o.getJSONArray("ids"))
                        "B" -> onBundle(o.getJSONObject("b"))
                    }
                } catch (_: Exception) { /* የተበላሸ መልዕክት ችላ ይባላል */ }
            }
        }
        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }

    private suspend fun onSummary(endpointId: String, idsJson: JSONArray) {
        val theirs = HashSet<String>().apply { for (i in 0 until idsJson.length()) add(idsJson.getString(i)) }
        // አስቸኳይ ጥቅሎች መጀመሪያ ይላካሉ
        for (b in dao.carryable(System.currentTimeMillis()).sortedByDescending { it.urgent }) {
            if (b.id in theirs) continue
            val msg = JSONObject().put("t", "B").put("b", toJson(b))
            client.sendPayload(endpointId, Payload.fromBytes(msg.toString().toByteArray()))
            // የራሴ ሪፖርት ለአንድ ስልክ ተላልፏል → "በመንገድ ላይ"
            if (b.mine && b.kind == Kind.REPORT && b.status == Status.DRAFT) {
                dao.setStatus(b.id, Status.IN_TRANSIT)
            }
        }
    }

    private suspend fun onBundle(j: JSONObject) {
        val b = fromJson(j)
        if (b.expiresAt < System.currentTimeMillis()) return
        if (dao.get(b.id) != null) return

        when {
            // 1. ሪፖርት ለወረዳ ስልክ ደርሷል
            b.kind == Kind.REPORT && isWoreda() -> {
                val key = woredaPrivateKey()
                val plain = key?.let { Crypto.decrypt(b.blob, it) }
                if (plain != null) {
                    dao.insertReceived(ReceivedEntity(b.id, String(plain), System.currentTimeMillis()))
                    dao.insert(b.copy(consumed = true))      // id እንዲታወቅ ይቀራል፣ ግን አይተላለፍም
                    createAck(b)
                } else {
                    dao.insert(b)                            // መፍታት አልተቻለም፤ እንደተሸካሚ ይቀጥል
                }
            }
            // 2. ACK ለኔ ደርሷል
            b.kind == Kind.ACK && b.dest == nodeId -> {
                dao.insert(b.copy(consumed = true))
                dao.setStatus(b.blob, Status.DELIVERED)
            }
            // 3. ACK ለሌላ ሰው — ተሸካሚ ሆኖ ይቀጥላል፣ የተረጋገጠውን ሪፖርት ቅጂ ግን ያጠፋል
            b.kind == Kind.ACK -> {
                dao.insert(b)
                dao.deleteCarried(b.blob)
            }
            // 4. ሌላ ሪፖርት — ተሸካሚ ሆኖ ይቀጥላል
            else -> dao.insert(b)
        }
    }

    private suspend fun createAck(report: BundleEntity) {
        val now = System.currentTimeMillis()
        dao.insert(
            BundleEntity(
                id = UUID.randomUUID().toString(),
                kind = Kind.ACK,
                dest = report.origin,
                origin = nodeId,
                blob = report.id,
                createdAt = now,
                expiresAt = now + TTL_MS,
                mine = false,
                consumed = false,
                title = "",
                urgent = report.urgent,
                status = Status.DRAFT
            )
        )
    }

    // ---------- JSON ----------

    private fun toJson(b: BundleEntity) = JSONObject()
        .put("id", b.id).put("kind", b.kind).put("dest", b.dest).put("origin", b.origin)
        .put("blob", b.blob).put("createdAt", b.createdAt).put("expiresAt", b.expiresAt)
        .put("urgent", b.urgent)

    private fun fromJson(o: JSONObject) = BundleEntity(
        id = o.getString("id"), kind = o.getString("kind"), dest = o.getString("dest"),
        origin = o.getString("origin"), blob = o.getString("blob"),
        createdAt = o.getLong("createdAt"), expiresAt = o.getLong("expiresAt"),
        mine = false, consumed = false, title = "", urgent = o.optBoolean("urgent"),
        status = Status.DRAFT
    )
}
