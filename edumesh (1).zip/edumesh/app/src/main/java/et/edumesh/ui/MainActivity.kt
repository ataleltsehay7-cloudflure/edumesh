package et.edumesh.ui

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import et.edumesh.crypto.Crypto
import et.edumesh.data.*
import et.edumesh.mesh.MeshManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.UUID

class MainActivity : ComponentActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var db: AppDb
    private lateinit var mesh: MeshManager
    private lateinit var nodeId: String

    private fun requiredPermissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= 33 -> arrayOf(
            Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.NEARBY_WIFI_DEVICES
        )
        Build.VERSION.SDK_INT >= 31 -> arrayOf(
            Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.ACCESS_FINE_LOCATION
        )
        else -> arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("edumesh", Context.MODE_PRIVATE)
        nodeId = prefs.getString("nodeId", null) ?: ("N" + UUID.randomUUID().toString().take(8)).also {
            prefs.edit().putString("nodeId", it).apply()
        }
        db = AppDb.get(this)

        // ማሳሰቢያ: ለምርት የግል ቁልፍ በAndroid Keystore/EncryptedSharedPreferences ይቀመጥ።
        mesh = MeshManager(
            this, db, nodeId,
            isWoreda = { prefs.getBoolean("isWoreda", false) },
            woredaPrivateKey = { prefs.getString("woredaPriv", null) }
        )

        setContent {
            MaterialTheme {
                val launcher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestMultiplePermissions()
                ) { result -> if (result.values.all { it }) mesh.start() }

                LaunchedEffect(Unit) { launcher.launch(requiredPermissions()) }
                App(prefs, db, nodeId)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::mesh.isInitialized) mesh.stop()
    }
}

// ================= UI =================

@Composable
fun App(prefs: SharedPreferences, db: AppDb, nodeId: String) {
    var tab by remember { mutableIntStateOf(0) }
    var isWoreda by remember { mutableStateOf(prefs.getBoolean("isWoreda", false)) }
    val tabs = buildList {
        add("አዲስ ሪፖርት"); add("የተላኩ")
        if (isWoreda) add("የደረሱ")
        add("ቅንብር")
    }
    if (tab >= tabs.size) tab = 0

    Scaffold { pad ->
        Column(Modifier.padding(pad)) {
            ScrollableTabRow(selectedTabIndex = tab) {
                tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
            }
            when (tabs[tab]) {
                "አዲስ ሪፖርት" -> ReportForm(prefs, db, nodeId) { tab = 1 }
                "የተላኩ" -> SentList(db)
                "የደረሱ" -> ReceivedList(db)
                else -> SettingsScreen(prefs, isWoreda) { isWoreda = it }
            }
        }
    }
}

@Composable
fun ReportForm(prefs: SharedPreferences, db: AppDb, nodeId: String, onSaved: () -> Unit) {
    val scope = rememberCoroutineScope()
    var school by remember { mutableStateOf("") }
    var kebele by remember { mutableStateOf("") }
    var period by remember { mutableStateOf("") }
    var eb by remember { mutableStateOf("") }
    var eg by remember { mutableStateOf("") }
    var pb by remember { mutableStateOf("") }
    var pg by remember { mutableStateOf("") }
    var tt by remember { mutableStateOf("") }
    var tp by remember { mutableStateOf("") }
    var book by remember { mutableStateOf(false) }
    var water by remember { mutableStateOf(false) }
    var urgent by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("የትምህርት ቤት ወርሃዊ ሪፖርት", style = MaterialTheme.typography.titleLarge)
        Text("ኢንተርኔት አያስፈልግም — መረጃው በስልክዎ ይቀመጣል።", style = MaterialTheme.typography.bodySmall)

        OutlinedTextField(school, { school = it }, label = { Text("የትምህርት ቤት ስም") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(kebele, { kebele = it }, label = { Text("ቀበሌ") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(period, { period = it }, label = { Text("የሪፖርት ወር (ለምሳሌ 2019-03)") }, modifier = Modifier.fillMaxWidth())

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumField("የተመዘገቡ ወንድ", eb, Modifier.weight(1f)) { eb = it }
            NumField("የተመዘገቡ ሴት", eg, Modifier.weight(1f)) { eg = it }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumField("የተገኙ ወንድ", pb, Modifier.weight(1f)) { pb = it }
            NumField("የተገኙ ሴት", pg, Modifier.weight(1f)) { pg = it }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumField("አጠቃላይ መምህራን", tt, Modifier.weight(1f)) { tt = it }
            NumField("የተገኙ መምህራን", tp, Modifier.weight(1f)) { tp = it }
        }

        CheckRow("የመማሪያ መጽሐፍ እጥረት አለ", book) { book = it }
        CheckRow("የንጹህ ውሃ/መጸዳጃ ችግር አለ", water) { water = it }
        CheckRow("አስቸኳይ ጉዳይ (ቅድሚያ ይሰጠዋል)", urgent) { urgent = it }

        OutlinedTextField(note, { note = it }, label = { Text("ተጨማሪ ማስታወሻ") }, modifier = Modifier.fillMaxWidth(), minLines = 3)

        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val pub = prefs.getString("woredaPub", "").orEmpty()
                val n = listOf(eb, eg, pb, pg, tt, tp).map { it.toIntOrNull() }
                when {
                    school.isBlank() || kebele.isBlank() || period.isBlank() -> error = "ስም፣ ቀበሌና ወር ያስገቡ።"
                    n.any { it == null } -> error = "ሁሉንም ቁጥሮች ይሙሉ።"
                    n[2]!! > n[0]!! || n[3]!! > n[1]!! -> error = "የተገኙ ተማሪዎች ከተመዘገቡት መብለጥ አይችሉም።"
                    n[5]!! > n[4]!! -> error = "የተገኙ መምህራን ከጠቅላላው መብለጥ አይችሉም።"
                    pub.isBlank() -> error = "መጀመሪያ በ«ቅንብር» የወረዳውን ቁልፍ ያስገቡ።"
                    else -> {
                        error = null
                        val report = EducationReport(
                            school.trim(), kebele.trim(), period.trim(),
                            n[0]!!, n[1]!!, n[2]!!, n[3]!!, n[4]!!, n[5]!!,
                            book, water, urgent, note.trim()
                        )
                        scope.launch(Dispatchers.IO) {
                            val now = System.currentTimeMillis()
                            db.dao().insert(
                                BundleEntity(
                                    id = UUID.randomUUID().toString(),
                                    kind = Kind.REPORT, dest = "WOREDA", origin = nodeId,
                                    blob = Crypto.encrypt(report.toJson().toByteArray(), pub),
                                    createdAt = now, expiresAt = now + MeshManager.TTL_MS,
                                    mine = true, consumed = false,
                                    title = "${report.schoolName} — ${report.period}",
                                    urgent = urgent, status = Status.DRAFT
                                )
                            )
                        }
                        onSaved()
                    }
                }
            }
        ) { Text("አስቀምጥ (ሌላ ስልክ ሲገናኝ በራሱ ይላካል)") }
    }
}

@Composable
fun NumField(label: String, value: String, modifier: Modifier, onChange: (String) -> Unit) {
    OutlinedTextField(
        value, { onChange(it.filter(Char::isDigit).take(6)) },
        label = { Text(label) }, modifier = modifier, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
    )
}

@Composable
fun CheckRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked, onChange)
        Text(text)
    }
}

@Composable
fun SentList(db: AppDb) {
    val mine by db.dao().observeMine().collectAsState(initial = emptyList())
    val carried by db.dao().observeCarriedCount().collectAsState(initial = 0)

    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("በስልክዎ የሚሸከሙት የሌሎች (የተመሰጠሩ) ጥቅሎች: $carried", style = MaterialTheme.typography.bodySmall)
        if (mine.isEmpty()) Text("ገና ሪፖርት አልላኩም።")
        mine.forEach { b ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text((if (b.urgent) "⚠ " else "") + b.title, style = MaterialTheme.typography.titleMedium)
                    Text(
                        when (b.status) {
                            Status.DELIVERED -> "ደርሷል ✓"
                            Status.IN_TRANSIT -> "በመንገድ ላይ…"
                            else -> "ተዘጋጅቷል — ሌላ ስልክ እስኪገናኝ በመጠበቅ ላይ"
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ReceivedList(db: AppDb) {
    val items by db.dao().observeReceived().collectAsState(initial = emptyList())
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("የደረሱ ሪፖርቶች: ${items.size}", style = MaterialTheme.typography.titleMedium)
        items.mapNotNull { runCatching { EducationReport.fromJson(it.json) }.getOrNull() }
            .sortedByDescending { it.urgent }
            .forEach { r ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text((if (r.urgent) "⚠ " else "") + "${r.schoolName} (${r.kebele}) — ${r.period}", style = MaterialTheme.typography.titleMedium)
                        Text("ተማሪዎች: ተመዝግበው ${r.enrolledBoys + r.enrolledGirls} (ወ ${r.enrolledBoys} / ሴ ${r.enrolledGirls}) · ተገኝተው ${r.presentBoys + r.presentGirls}")
                        Text("መምህራን: ${r.teachersPresent}/${r.teachersTotal}")
                        if (r.textbookShortage) Text("• የመጽሐፍ እጥረት")
                        if (r.waterSanitationIssue) Text("• የውሃ/መጸዳጃ ችግር")
                        if (r.note.isNotBlank()) Text("ማስታወሻ: ${r.note}")
                    }
                }
            }
    }
}

@Composable
fun SettingsScreen(prefs: SharedPreferences, isWoreda: Boolean, onRole: (Boolean) -> Unit) {
    val clipboard = LocalClipboardManager.current
    var pub by remember { mutableStateOf(prefs.getString("woredaPub", "").orEmpty()) }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("ቅንብር", style = MaterialTheme.typography.titleLarge)

        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(isWoreda, {
                prefs.edit().putBoolean("isWoreda", it).apply()
                onRole(it)
            })
            Spacer(Modifier.width(8.dp))
            Text("የወረዳ ጽ/ቤት ሁነታ (ሪፖርት ተቀባይ)")
        }

        if (isWoreda) {
            Button(onClick = {
                val (p, s) = Crypto.generateKeyPair()
                prefs.edit().putString("woredaPub", p).putString("woredaPriv", s).apply()
                pub = p
            }) { Text("የወረዳ ቁልፍ አመንጭ (አንዴ ብቻ)") }
            Text("የግል ቁልፉ በዚህ ስልክ ብቻ ይቀራል። ከታች ያለውን ይፋዊ ቁልፍ ገልብጠው ወደ ትምህርት ቤቶች ስልኮች ያስገቡ (ለምሳሌ በወረቀት ወይም በቀጥታ በመገናኘት)።", style = MaterialTheme.typography.bodySmall)
        }

        OutlinedTextField(
            pub, {
                pub = it
                prefs.edit().putString("woredaPub", it.trim()).apply()
            },
            label = { Text("የወረዳ ይፋዊ ቁልፍ (public key)") },
            modifier = Modifier.fillMaxWidth(), minLines = 4
        )
        if (pub.isNotBlank()) {
            OutlinedButton(onClick = { clipboard.setText(AnnotatedString(pub)) }) { Text("ቁልፉን ቅዳ") }
        }
    }
}
