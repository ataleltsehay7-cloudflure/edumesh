package et.edumesh.crypto

import android.util.Base64
import java.nio.ByteBuffer
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.SecureRandom
import java.security.spec.MGF1ParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource
import javax.crypto.spec.SecretKeySpec

/**
 * Hybrid ኢንክሪፕሽን፦ ሪፖርቱ በዘፈቀደ AES-256-GCM ቁልፍ ይመሰጠራል፣
 * ያ ቁልፍ ደግሞ በወረዳው RSA-2048 public key (OAEP) ይታሸጋል።
 * በመንገድ ላይ ያሉ ተሸካሚ ስልኮች ይዘቱን ማንበብ አይችሉም።
 *
 * ቅርጸት: [2 ባይት: የታሸገው ቁልፍ ርዝመት][የታሸገ ቁልፍ][12 ባይት IV][ciphertext+tag]
 */
object Crypto {
    private val rng = SecureRandom()
    private val oaep = OAEPParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA1, PSource.PSpecified.DEFAULT)

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP)

    /** (publicKeyB64, privateKeyB64) — በወረዳ ስልክ አንዴ ያሂዱ */
    fun generateKeyPair(): Pair<String, String> {
        val kpg = KeyPairGenerator.getInstance("RSA")
        kpg.initialize(2048)
        val kp = kpg.generateKeyPair()
        return b64(kp.public.encoded) to b64(kp.private.encoded)
    }

    fun encrypt(plain: ByteArray, publicKeyB64: String): String {
        val pub = KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(unb64(publicKeyB64.trim())))
        val aesKey = ByteArray(32).also { rng.nextBytes(it) }
        val iv = ByteArray(12).also { rng.nextBytes(it) }

        val aes = Cipher.getInstance("AES/GCM/NoPadding")
        aes.init(Cipher.ENCRYPT_MODE, SecretKeySpec(aesKey, "AES"), GCMParameterSpec(128, iv))
        val ct = aes.doFinal(plain)

        val rsa = Cipher.getInstance("RSA/ECB/OAEPPadding")
        rsa.init(Cipher.ENCRYPT_MODE, pub, oaep)
        val wrapped = rsa.doFinal(aesKey)

        val buf = ByteBuffer.allocate(2 + wrapped.size + iv.size + ct.size)
        buf.putShort(wrapped.size.toShort()).put(wrapped).put(iv).put(ct)
        return b64(buf.array())
    }

    /** ካልተሳካ (የተሳሳተ ቁልፍ/የተበላሸ መረጃ) null ይመልሳል */
    fun decrypt(blobB64: String, privateKeyB64: String): ByteArray? = try {
        val priv = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(unb64(privateKeyB64.trim())))
        val buf = ByteBuffer.wrap(unb64(blobB64))
        val wrapped = ByteArray(buf.short.toInt() and 0xFFFF).also { buf.get(it) }
        val iv = ByteArray(12).also { buf.get(it) }
        val ct = ByteArray(buf.remaining()).also { buf.get(it) }

        val rsa = Cipher.getInstance("RSA/ECB/OAEPPadding")
        rsa.init(Cipher.DECRYPT_MODE, priv, oaep)
        val aesKey = rsa.doFinal(wrapped)

        val aes = Cipher.getInstance("AES/GCM/NoPadding")
        aes.init(Cipher.DECRYPT_MODE, SecretKeySpec(aesKey, "AES"), GCMParameterSpec(128, iv))
        aes.doFinal(ct)
    } catch (e: Exception) {
        null
    }
}
